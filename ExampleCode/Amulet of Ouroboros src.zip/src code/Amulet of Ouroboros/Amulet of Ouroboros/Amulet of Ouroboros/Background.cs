﻿using Microsoft.Xna.Framework.Content;

namespace Amulet_of_Ouroboros.Sprites
{
    class Background : Sprite
    {
        public Background(ContentManager content, string assetName)
            : base(content, assetName)
        {
        }
    }
}
