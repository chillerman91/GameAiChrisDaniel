﻿using Microsoft.Xna.Framework.Content;

namespace SensorsAndSuch.Sprites
{
    class Background : Sprite
    {
        public Background(ContentManager content, string assetName)
            : base(content, assetName)
        {
        }
    }
}
